const css = `
		
/* цвет и блюр фона панели управления */
/* color and blur control panel background */
        .ytp-chrome-controls {--yt-spec-overlay-background-medium-light: rgba(0, 0, 0, 0.3) !important;}
        .ytp-chrome-controls {--yt-frosted-glass-backdrop-filter-override: blur(16px) !important;}
		
/* блюр меню настроек и правого клика */
/* blur the settings menu and right click */
        .ytp-popup {--yt-frosted-glass-backdrop-filter-override: blur(16px) !important;}
		
/* блюр окна статистики сисадмина */
/* blur system administrator statistics window */
        .html5-video-info-panel {backdrop-filter: blur(16px) !important;}
		
/* цвет, затемнение, закругление, блюр фона всплывающих секунд (появляются при нажатии влево/вправо на курсоре клавы) */
/* blur, color, darkening, rounding of the background of pop-up seconds (appear when you press left/right on the keyboard cursor) */
		.ytp-seek-overlay-animation {background-color: rgba(0, 0, 0, 0.3) !important;}
		.ytp-seek-overlay-animation {padding: 8px 16px !important;}
		.ytp-seek-overlay-animation {border-radius: 18px !important;}
        .ytp-seek-overlay-animation {backdrop-filter: blur(16px) !important;}
		
/* цвет и закругление фона всплывающего текста громкости в центре экрана (появляется при нажатии вверх/вниз на курсоре клавы) */
/* color and rounded background of the volume pop-up text in the center of the screen (appears when you press up/down on the keyboard cursor) */
        .ytp-bezel-text {background-color: rgba(0, 0, 0, 0.3) !important;}
		.ytp-bezel-text {border-radius: 18px !important;}
		
/* цвет и блюр фона всплывающего плей/пауза в центре экрана */
/* color and blur background pop-up play/pause in the center of the screen */
        .ytp-bezel {background-color: rgba(0, 0, 0, 0.3) !important;}
        .ytp-bezel {backdrop-filter: blur(16px) !important;}
		
/* цвет и блюр фона всплывающих подсказок горячих клавиш */
/* color and blur background pop-up hotkey hints */
        .ytp-tooltip {--yt-spec-overlay-background-medium-light: rgba(0, 0, 0, 0.3) !important;}
        .ytp-tooltip {backdrop-filter: blur(16px) !important;}
		
/* цвет фона времени при наведении курсора на прогресс бар */
/* color background of the time when hovering over the progress bar */
        .ytp-tooltip-progress-bar-pill {background-color: rgba(0, 0, 0, 0.3) !important;}
		
/* цвет и рамка фона превью которая появляется при наведении курсора на прогресс бар (избавляет от стробоскопа при быстром перемещении) */
/* background color and frame for video preview when hovering over the timeline (eliminates stroboscopic effect when moving the cursor quickly) */
        .ytp-tooltip-progress-bar-style {background-color: rgba(0, 0, 0, 0.3) !important;}
        .ytp-tooltip-progress-bar-style {padding: 5px !important;}
        .ytp-tooltip-progress-bar-style {border-radius: 10px !important;}
		
/* цвет и блюр панели кнопок лайков в фуллскрине */
/* color and blur like button panel in full screen mode */
        .ytPlayerQuickActionButtonsHost {background-color: rgba(0, 0, 0, 0.3) !important;}
        .ytPlayerQuickActionButtonsHost {backdrop-filter: blur(16px) !important;}

/* цвет и блюр фона названия ролика в фуллскрине */
/* blur and darken the background of the video title in full screen */
        .ytPlayerOverlayVideoDetailsRendererHost {background-color: rgba(0, 0, 0, 0.3) !important;}
        .ytPlayerOverlayVideoDetailsRendererHost {backdrop-filter: blur(16px) !important;}

    `;
    
const style = document.createElement('style');
style.textContent = css;
document.head.appendChild(style);
//________________________________________________________________________________________________________

// fixing a bug control from => https://github.com/Dim0s/YouTube-fix-control
let VolumeDown = false
let ProgressDown = false
let LiveBadgeDown = false

const Int = setInterval(() => {
	if (location.href.includes("/watch?v=") ||
		location.href.includes("/embed/") ||
		location.href.includes("/live/")) {
		clearInterval(Int)
		const Int2 = setInterval(() => {
			const vol = document.querySelector('.ytp-volume-slider')
			const progress = document.querySelector('.ytp-progress-bar')
			const progressMove = document.querySelector('.ytp-progress-bar')
			const lBadge = document.querySelector('.ytp-live-badge')
			const player = document.querySelector('#movie_player')
			if (vol && progress && lBadge && player) {
				clearInterval(Int2)
				vol.addEventListener('mousedown', () => VolumeDown = true)
				progress.addEventListener('mousedown', () => ProgressDown = true)
				lBadge.addEventListener('mousedown', () => LiveBadgeDown = true)
				document.addEventListener('mouseup', () => {
					if (VolumeDown == true || ProgressDown == true || LiveBadgeDown == true) {
						VolumeDown = false
						ProgressDown = false
						LiveBadgeDown = false
						player.focus()
					}
				})
				progressMove.addEventListener('mousemove', () => 
				{
					progress.dispatchEvent(new MouseEvent('mouseover', {bubbles: true}));
				})
			}
		}, 500)
	}
}, 500)
//________________________________________________________________________________________________________