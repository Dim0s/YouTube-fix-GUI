const css = `
	
/* отключение нового фона панели управления */
/* disabling new Control Panel background */
        .ytp-chrome-controls {--yt-spec-overlay-background-medium-light: rgba(0, 0, 0, 0)!important;}
		
/* перемещение панели управления чуть ниже */
/* moving the control panel lower */
        .ytp-chrome-controls {transform: translateY(7px) !important;}
		
/* перемещение прогресс-бара чуть ниже */
/* moving the progress bar lower */
        .ytp-progress-bar-container {transform: translateY(15px) !important;}
		
/* цвет фона прогресс бара светлей */
/* fone progress bar color is lighter */
        .ytp-progress-list {background-color: rgba(255, 255, 255, 0.2) !important;}
		
/* включение старого градиента фона сверху и снизу плеера, нельзя юзать колесо мышки в фуллскрине!!! */
/* background gradient at the top and bottom of the player */
        .ytp-gradient-top {display: block !important;}
        .ytp-gradient-bottom {display: block !important;}
		
/* цвет меню настроек и правого клика */
/* color the settings menu and right click */
        .ytp-popup {background-color: rgba(28, 28, 28, 0.9) !important;}
		
/* цвет, затемнение, закругление фона всплывающих секунд (появляются при нажатии влево/вправо на курсоре клавы) */
/* color, darkening, rounding of the background of pop-up seconds (appear when you press left/right on the keyboard cursor) */
        .ytp-seek-overlay-animation {background-color: rgba(28, 28, 28, 0.8) !important;}
        .ytp-seek-overlay-animation {padding: 8px 16px !important;}
        .ytp-seek-overlay-animation {border-radius: 18px !important;}
		
/* цвет, закругление фона всплывающего текста громкости в центре экрана (появляется при нажатии вверх/вниз на курсоре клавы) */
/* color, rounded background of the volume pop-up text in the center of the screen (appears when you press up/down on the keyboard cursor) */
        .ytp-bezel-text {background-color: rgba(28, 28, 28, 0.8) !important;}
        .ytp-bezel-text {border-radius: 18px !important;}

/* цвет фона всплывающего плей/пауза в центре экрана */
/* color background pop-up play/pause in the center of the screen */
        .ytp-bezel {background-color: rgba(28, 28, 28, 0.8) !important;}
		
/* цвет фона всплывающих подсказок горячих клавиш */
/* color background of hotkey tooltips */
        .ytp-tooltip {--yt-spec-overlay-background-medium-light: rgba(28, 28, 28, 0.8) !important;}
		
/* цвет фона времени при наведении курсора на прогресс бар */
/* color background of the time when hovering over the progress bar */
        .ytp-tooltip-progress-bar-pill {background-color: rgba(28, 28, 28, 0.8) !important;}
		
/* цвет фона превью при наведении курсора на тайм лайн (избавляет от стробоскопа) */
/* color preview background when hovering over the timeline (eliminates the strobe) */
        .ytp-tooltip-progress-bar-style {background-color: rgba(28, 28, 28, 0.8) !important;}
		
/* удаление панели кнопок лайков в фуллскрине */
/* Removing the likes panel in fullscreen mode */
        .ytPlayerQuickActionButtonsHostDisableBackdropFilter {display: none !important;}
		
/* удаление шлака предложки при прокрутке колеса в фуллскрине */
/* Removing slag from panel recomended videos when scrolling the wheel in full screen */
        .ytp-fullscreen-grid {display: none !important;}
		
/* удаление чата в фуллскрине */
/* Deleting a chat in fullscreen*/
        #panels-full-bleed-container {display: none !important;}
		
    `;
    
const style = document.createElement('style');
style.textContent = css;
document.head.appendChild(style);
//________________________________________________________________________________________________________

// fixing a bug control from => https://github.com/Dim0s/YouTube-fix-control
let VolumeDown = false
let ProgressDown = false
let LiveBadgeDown = false

const Int = setInterval(() => {
	if (location.href.includes("/watch?v=") ||
		location.href.includes("/embed/") ||
		location.href.includes("/live/")) {
		clearInterval(Int)
		const Int2 = setInterval(() => {
			const vol = document.querySelector('.ytp-volume-slider')
			const progress = document.querySelector('.ytp-progress-bar')
			const progressMove = document.querySelector('.ytp-progress-bar')
			const lBadge = document.querySelector('.ytp-live-badge')
			const player = document.querySelector('#movie_player')
			if (vol && progress && lBadge && player) {
				clearInterval(Int2)
				vol.addEventListener('mousedown', () => VolumeDown = true)
				progress.addEventListener('mousedown', () => ProgressDown = true)
				lBadge.addEventListener('mousedown', () => LiveBadgeDown = true)
				document.addEventListener('mouseup', () => {
					if (VolumeDown == true || ProgressDown == true || LiveBadgeDown == true) {
						VolumeDown = false
						ProgressDown = false
						LiveBadgeDown = false
						player.focus()
					}
				})
				progressMove.addEventListener('mousemove', () => 
				{
					progress.dispatchEvent(new MouseEvent('mouseover', {bubbles: true}));
				})
			}
		}, 500)
	}
}, 500)
//________________________________________________________________________________________________________